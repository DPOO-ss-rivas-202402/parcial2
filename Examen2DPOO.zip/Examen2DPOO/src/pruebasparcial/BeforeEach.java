package pruebasparcial;

public @interface BeforeEach {

}

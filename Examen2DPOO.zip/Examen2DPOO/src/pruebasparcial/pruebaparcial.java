package pruebasparcial;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import logica.Calculadora;

public class pruebaparcial {
	private double a = 1;
	private double b = -3;
	private double c =2;
	private Parcial parcial;

	@BeforeEach
	public void setUp() {
		this.parcial = new Calculadora();
	}
	
	@Test
	public void divisionTest() throws Exception {
		assertEquals( this.parcial.formula(1, -3, 2));
		assertThrows(Exception.class, () -> this.parcial.formula(10,0));
	}

}

package presentacionparcial;

import logicaparcial.Parcial;
public class Principalparcial {

	public static void main(String[] args) {
      
        System.out.println((1, -3, 2)); 
        System.out.println(formula(1, 2, 5));  
    }
}

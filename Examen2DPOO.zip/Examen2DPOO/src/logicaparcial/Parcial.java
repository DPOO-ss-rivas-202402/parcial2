package logicaparcial;


public  class Parcial {
	public double  formula(double a, double b, double c) throws Exception {
		if(a == 0) {
			throw new Exception("El valor de a no puede ser 0");
		}else {
	
			double x = b*b - 4*a*c; 
			if(x > 0);
			
				double raiz1 = (-b + Math.sqrt(x)) / (2*a);
        		double raiz2 = (-b - Math.sqrt(x)) / (2*a);
        		
					        
		     
		}
			
				
				
			
		
		return  raiz1, raiz2;

}
}